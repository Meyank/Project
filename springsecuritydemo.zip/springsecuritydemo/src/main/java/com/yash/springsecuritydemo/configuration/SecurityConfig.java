package com.yash.springsecuritydemo.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.yash.springsecuritydemo.serviceimpl.MyUserDetails;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/welcome").access("ADMIN").
		and().formLogin().loginPage("/login").loginProcessingUrl("/processLogin")
				.usernameParameter("userName").passwordParameter("password").defaultSuccessUrl("/home")
				.and().csrf().disable();
 System.out.println("in http");
	}

	@Autowired
	MyUserDetails myUserDetails;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(myUserDetails);
		System.out.println("setting usernname password");
//		.passwordEncoder(passwordEncoder());
	}

//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		return passwordEncoder;
//	}

	// @Autowired
	// UserDetailsService userDetailsService;

	// @Override
	// protected void configure(AuthenticationManagerBuilder auth) throws
	// Exception {
	//
	// auth.ldapAuthentication().contextSource(contextSource())
	//
	// .userDnPatterns("uid={0},ou=Users")
	// .userSearchBase("ou=Users")
	// .userSearchFilter("uid={0}")
	// .passwordCompare()
	// .passwordEncoder(new LdapShaPasswordEncoder())
	// .passwordAttribute("userPassword");

	// auth.userDetailsService(userDetailsService);
	// }
	// @Bean
	// public DefaultSpringSecurityContextSource contextSource() {
	// return new DefaultSpringSecurityContextSource(
	// Collections.singletonList("ldap://inidradc01.yash.com/"),
	// "dc=yash,dc=com");
	// }

}
