package com.yash.springsecuritydemo.DAOImpl;

//import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.springsecuritydemo.domain.UserInfo;

@Repository
public class UserDAOImpl {

//	@Autowired
//	private SessionFactory sessionFactory;

	public UserInfo getActiveUser(String userName) {
		UserInfo userInfo = new UserInfo();
		userInfo.setRoles("ADMIN");
		userInfo.setUsername("mayank");
		userInfo.setPassword("gautam");
		return userInfo;
	}

}
