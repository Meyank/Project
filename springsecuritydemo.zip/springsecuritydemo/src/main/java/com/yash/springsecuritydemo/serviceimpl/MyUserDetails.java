package com.yash.springsecuritydemo.serviceimpl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.yash.springsecuritydemo.DAOImpl.UserDAOImpl;
import com.yash.springsecuritydemo.domain.UserInfo;

@Service
public class MyUserDetails implements UserDetailsService {

	@Autowired
	UserDAOImpl userDAOImpl;

	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

		System.out.println("userNAme" + userName);
		UserInfo activeUserInfo = userDAOImpl.getActiveUser(userName);

		GrantedAuthority authority = new SimpleGrantedAuthority(activeUserInfo.getRoles());
		System.out.println(authority);
		UserDetails userDetail = (UserDetails) new User(activeUserInfo.getUsername(), activeUserInfo.getPassword(),
				Arrays.asList(authority));
		System.out.println(userDetail);
		return userDetail;
	}

}
