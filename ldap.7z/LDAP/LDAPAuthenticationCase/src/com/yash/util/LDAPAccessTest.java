package com.yash.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPAccessTest {

	private SearchResult searchResult;
	IntializeHashTableEnvironmentVariablesForContext icontext;
	String accountToLookup;
	Map<Object, List<Object>> mapofAttributesWithValues;

	public LDAPAccessTest() {
		icontext = new IntializeHashTableEnvironmentVariablesForContext();
		mapofAttributesWithValues = new HashMap<Object, List<Object>>();
	}

	public boolean testAuthentication(String email, String password) {
		Hashtable<String, Object> environment = icontext.intializeHashTableVariables(email, password);
		accountToLookup = "sAMAccountName=" + email.substring(0, email.indexOf("@"));
		InitialDirContext ctx = null;
		try {
			ctx = new InitialDirContext(environment);
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search("DC=yash,DC=com", accountToLookup,
					searchControls);
			System.out.println(results);
			
			if (results.hasMoreElements()) {
				searchResult = results.nextElement();
				System.out.println(searchResult.getName());
				return true;
			}
			ctx.close();
		} catch (NamingException e) {
			e.printStackTrace();
		}

		return false;
	}

	public Map<Object, List<Object>> printAllAttributes() {

		Attributes attributes = searchResult.getAttributes();
		System.out.println(attributes);
		if (attributes == null) {
			System.out.println("No attributes To Display");
			return null;

		}

		try {
			NamingEnumeration namingEnumeration = attributes.getAll();
			while (namingEnumeration.hasMore()) {
				Attribute attribute = (Attribute) namingEnumeration.next();
				List<Object> listOfAttributeValues = new ArrayList<Object>();
				NamingEnumeration e = attribute.getAll();
				while (e.hasMore()) {
					listOfAttributeValues.add(e.next());
				}
				mapofAttributesWithValues.put(attribute.getID(), listOfAttributeValues);
			}

		} catch (NamingException e) {
			e.printStackTrace();
		}
		
		return mapofAttributesWithValues;
	}

}
