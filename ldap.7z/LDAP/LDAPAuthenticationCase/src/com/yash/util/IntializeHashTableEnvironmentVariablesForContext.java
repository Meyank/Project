package com.yash.util;

import java.util.Hashtable;

import javax.naming.Context;

public class IntializeHashTableEnvironmentVariablesForContext {

	Hashtable<String, Object> environment;

	public Hashtable<String, Object> intializeHashTableVariables(String email, String password) {

		environment = new Hashtable<>();
		environment.put(Context.SECURITY_AUTHENTICATION, "simple");
		environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(Context.PROVIDER_URL, "ldap://inidradc01.yash.com/");
		environment.put(Context.SECURITY_PRINCIPAL, email);//username
		environment.put(Context.SECURITY_CREDENTIALS, password);//passowrd
		//environment.put("java.naming.ldap.attributes.binary", "objectSID");
		return environment;

	}

}
