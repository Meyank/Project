package com.yash.ycmscore.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.CategoryDAO;
import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.util.SessionFactoryUtil;

/**
 * This class is the implementation of CategoryDAO interface. This class will
 * have methods for handling category related operations such as listing all the
 * categories.
 * 
 * 
 * @version 0.0.1
 * 
 * @since 14 April, 2018
 * 
 * @Repository annotation is used in your DAO layer and annotates classes that
 *             perform Database tasks
 * 
 * @author aakash.jangid
 *
 */
@Repository
public class CategoryDAOImpl implements CategoryDAO {

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactoryUtil sessionFactoryUtil;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	/**
	 * this is the declaration of logger
	 * 
	 * @author minerva.shrivastava
	 */
	private static Logger logger=Logger.getLogger(CategoryDAOImpl.class);

	/**
	 * This method will fetch all the categories from the database and will be
	 * called whenever the list of the categories is required.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return List<Category> - This method will return a List of Category.
	 */
	@SuppressWarnings("unchecked")
	public List<Category> getAllCategories(int trashStatus, String dbname) {
		List<Category> categories = null;
		Session session = sessionFactoryUtil.getSessionFactoryForPassedDB(dbname).openSession();
		session.beginTransaction();
		Query query = session.createQuery("From Category WHERE trash=?");
		query.setInteger(0, trashStatus);
		categories = query.list();
		session.close();
		sessionFactoryUtil.getSessionFactoryForPassedDB(dbname).close();
		return categories;
	}

	/**
	 * This method will change the trash status of the category. It will fetch the
	 * particular category with the help of the id passed as a parameter and then it
	 * will update the trash status of the category.
	 * 
	 * @param id:int it is the id of the category by which the category will be fetched.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return boolean it will return true if the status has been updated
	 *         successfully else it will return false.
	 */
	public boolean changeTrashStatus(int id, String dbname) {
		Session session = sessionFactoryUtil.getSessionFactoryForPassedDB(dbname).openSession();
		Query query = session.createQuery("FROM Category WHERE id=:id");
		query.setInteger("id", id);
		Category category = (Category) query.uniqueResult();
		int trashStatus = category.getTrash();
		if (trashStatus == 1) {
			category.setTrash(0);
		} else {
			category.setTrash(1);
		}
		session.beginTransaction();
		session.update(category);
		session.getTransaction().commit();
		session.close();
		sessionFactoryUtil.getSessionFactoryForPassedDB(dbname).close();
		return true;
	}

	/**
	 * This method inserts the Category into the database through the hibernate 
	 * saveOrUpdate method in a transaction which is rolledback in case of an exception  
	 *
	 * @param category to be saved in the database
	 * 
	 * @return true if Category is added successfully otherwise false in case of some error
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean insert(Category category) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.getTransaction();
			transaction.begin();
			session.saveOrUpdate(category);
			transaction.commit();
			return true;
		} catch (HibernateException hx) {
			if (transaction != null) {
				logger.error("Transaction Rollback");
				transaction.rollback();
			}
			hx.printStackTrace();
			return false;
		} finally {
			session.close();
		}
	}

}