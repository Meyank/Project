package com.yash.ycmscore.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.yash.ycmscore.model.Video;

/**
 * This interface provides the services related to Video such as saving the
 * details of the video into the database, list the details of videos etc.
 * 
 * Functionalities provided- 1) Save details of Video. 2) Get Video details
 * Lists <br>
 * <br>
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 *
 */
public interface VideoService {
	/**
	 * This method saves the Video File at a particular location.
	 * 
	 * @author harmeet.saluja
	 * @param file
	 *            File that is to be saved at a given location
	 * @param title
	 *            unique title of the file that will be saved inside the
	 *            database
	 * @return true if the file is saved successfully, else returns false
	 */
	public boolean store(MultipartFile file, String title);

	/**
	 * This method will use the will call the method of the userDAO to get the
	 * list of videos.
	 * 
	 * @author harmeet.saluja
	 * @return the list of the videos
	 */
	public List<Video> videosList();

}
