package com.yash.ycmscore.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.UserDAO;
import com.yash.ycmscore.model.User;

/**
 * this is the implementation class for UserDAO interface
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 * @Repository annotation is used in your DAO layer and annotates classes that
 *             perform Database tasks
 */
@Repository
public class UserDAOImpl implements UserDAO {

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * this method will be used to add a User to the database
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be saved in the database
	 * @return true if user added successfully or false if their is some error
	 *         saving the object
	 */
	public boolean add(User user) {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Integer id = (Integer) session.save(user);
		session.getTransaction().commit();
		session.close();
		if (id != null)
			return true;
		else
			return false;

	}

	/**
	 * this method will update a user in the database
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be updated
	 * @return true if update is successful or false if the update is
	 *         unsuccessful
	 */
	public boolean update(User user) {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(user);
		session.getTransaction().commit();
		session.close();
		return true;

	}

	/**
	 * this method will delete a user in the database
	 * 
	 * @author ishan.juneja
	 * @param id
	 *            of the user to be deleted
	 * @return true if delete operation is successful and false if delete
	 *         operation is unsuccessful
	 */
	public boolean delete(int id) {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("delete from User where id=" + id);
		Integer number = query.executeUpdate();
		session.getTransaction().commit();
		session.close();
		if (number >= 0)
			return true;
		else
			return false;

	}

	/**
	 * this method will return a list of all the users in the database
	 * 
	 * @author ishan.juneja
	 * @return a list of all the users in the database
	 * @SuppressWarnings instruct the compiler to ignore or suppress, specified
	 *                   compiler warning in annotated element and all program
	 *                   elements inside that element.
	 */
	@SuppressWarnings("unchecked")
	public List<User> list() {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createSQLQuery("select * from users").addEntity(User.class);
		return (List<User>) query.list();

	}

}
