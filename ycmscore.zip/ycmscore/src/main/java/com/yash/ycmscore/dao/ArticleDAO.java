package com.yash.ycmscore.dao;

import java.util.List;

import com.yash.ycmscore.model.Article;

/**
 * this interface will provide the database related
 * functionality for Articles in the application
 * 
 * 
 * @author ishan.juneja
 *
 */
public interface ArticleDAO {

	/**
	 * this method will insert the information of an
	 * article in the database
	 * 
	 * @return not available if the alias or the document is 
	 * present previously in the database
	 */
	public String createNewArticle(Article article,String domain);
	
	
	public List<String> getAllArticles(String domain);
	
	public List<Article> listArticles(Article article,String domain);
	
	public boolean changeStatusToTrashStatus(int id,String domain);
	
	public boolean changeStatusToUntrashStatus(int id,String domain);
	
	public boolean changeStatusToPublishStatus(int id,String domain);

	public boolean changeStatusToUnpublishStatus(int id,String domain);
	
	public boolean changeStatusToUnFeatured(int id,String domain);
	
	public boolean changeStatusToFeatured(int id,String domain);
	
	public int deleteArticle(int id,String domain);

	public List<Article> getAllUntrashedArticles(String domain);

}
