package com.yash.ycmscore.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;


/**
 * This class will do all the LDAP related Functionalities such as authenticating,blocking,userDetails etc.
 *
 * Date - 05/04/2018
 * 
 * @author Mayank
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 */
@Service
@PropertySource("classpath:resource/ldapconfig.properties")
public class LDAPService  {

	/**
	 * this is the declaration of logger
	 * 
	 * @author minerva.shrivastava
	 */
	private static Logger logger=Logger.getLogger(UserServiceImpl.class);
	/**
	 * This is the environment bean needed here in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;
	
	/**
	 * the initialDirContext which takes LDAP properties in hashtable
	 * @author minerva.shrivastava
	 */
	private InitialDirContext context=null;

	/**
	 * This will represent one element within the naming enumeration or hold the
	 * details of the user
	 * 
	 * @author mayank
	 */
	private SearchResult searchResult;

	/**
	 * This is to take environmentForContext i.e it will initialize the
	 * properties to connect with LDAP.
	 * 
	 * @author mayank
	 */

	private Hashtable<String, Object> environmentForContext;

	/**
	 * This variable will hold the account whose details you want to fetch from
	 * LDAP(A.D).
	 * 
	 * @author mayank
	 */

	private String accountToLookup;

	/**
	 * This map will hold the details of the user which we have fetched from
	 * LDAP DB.
	 * 
	 * @author mayank
	 */
	private Map<Object, List<Object>> mapofAttributesWithValues;

	/**
	 * This variable is to track no. of attempts done by user for login
	 * 
	 * @author mayank
	 */

	private static int loginAttempts = 3;

	/**
	 * This will save the time at which account should release
	 * 
	 * @author mayank
	 */
	private static long timeAtAccountShouldRelease = 0;
	
	
	
	/**
	 * This method reads the properties from the ldap.properties file placed in the resources folder 
	 * on classpath, and initializes the hashtable variables with context properties :
	 * 1.INITIAL_CONTEXT_FACTORY
	 * 2.SECURITY_AUTHENTICATION
	 * 3.PROVIDER_URL
	 * 4.SECURITY_PRINCIPAL
	 * 5.SECURITY_CREDENTIALS
	 * 
	 * @param email - yash emailId
	 * @param password - yash password
	 *           
	 * @return Hashtable environment for context - to initialize the context
	 * 
	 * @author minerva.shrivastava
	 */
	public Hashtable<String, Object> intializeHashTableVariables(String email, String password) {

		environmentForContext = new Hashtable<String, Object>();
		environmentForContext.put(Context.INITIAL_CONTEXT_FACTORY, environment.getProperty("LDAP_INITIAL_CONTEXT_FACTORY"));
		environmentForContext.put(Context.SECURITY_AUTHENTICATION, environment.getProperty("LDAP_SECURITY_AUTHENTICATION"));
		environmentForContext.put(Context.PROVIDER_URL, environment.getProperty("LDAP_PROVIDER_URL"));
		environmentForContext.put(Context.SECURITY_PRINCIPAL, email);// email of the user
		environmentForContext.put(Context.SECURITY_CREDENTIALS, password);// password of the user
		return environmentForContext;

	}

	/**
	 * This method will authenticate the user on the basis of details entered by user.
	 * 1.It will build an InitialDirContext based on the hashtable variable above.
	 * 2.It then performs search in SEARCH_BASE = "DC=yash,DC=com" and SUBTREE_SCOPE type control
	 * 		and account to lookup obtaining the result as Naming Enumeration<Search Result>.
	 * 3.If the result has elements 
	 * 		then the user is authenticated otherwise the authentication fails.
	 * 
	 * @param email - Yash emailId entered by customer
	 * @param password - Yash password entered by customer
	 * @return true if context is obtained i.e details are correct . 
	 * 		   false- if no context is obtained
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean userAuthentication(String email, String password) {
			
			if(email == null || password == null) return false;
			
			boolean authenticated = false;
			
		try {

			context = new InitialDirContext(intializeHashTableVariables(email, password));
			accountToLookup = "sAMAccountName=" + email.substring(0, email.indexOf("@"));
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration<SearchResult> results = context.search(environment.getProperty("LDAP_SEARCH_BASE"), accountToLookup, searchControls);
			if (results.hasMoreElements()) {
				searchResult = results.nextElement();
				authenticated = true;
				logger.info(searchResult);
			}
			return authenticated;
		} catch (NamingException namingException) {
			logger.error(namingException);

		}finally {
			try {
				if (context != null) context.close();
			} catch (NamingException ne) {
				logger.error(ne);
			}
		}
		return authenticated;

	}

	/**
	 * This method will return you all the attributes of the user whoever is
	 * binded to ldap i.e after authentication
	 * 
	 * @author mayank
	 * @return mapofAttributesWithValues i.e map with all the details
	 */
	public Map<Object, List<Object>> getAuthenticatedUserDetails() {

		Attributes attributes = searchResult.getAttributes();
		

		if (attributes == null) {
			
			return null;

		}

		try {
			NamingEnumeration namingEnumeration = attributes.getAll();
			mapofAttributesWithValues = new HashMap<Object, List<Object>>();
			while (namingEnumeration.hasMore()) {
				Attribute attribute = (Attribute) namingEnumeration.next();
				List<Object> listOfAttributeValues = new ArrayList<Object>();
				NamingEnumeration e = attribute.getAll();

				while (e.hasMore()) {
					listOfAttributeValues.add(e.next());
				}
				mapofAttributesWithValues.put(attribute.getID(), listOfAttributeValues);
			}
		}
		catch (NamingException e) {
			e.printStackTrace();
		}

		return mapofAttributesWithValues;

	}

	/**
	 * This method is to calculate the current time and the time at which
	 * account should release i.e user is allowed to try again for login
	 * 
	 * @author mayank
	 * @return timeAtAccountShouldRelease at which account should release i.e user is allowed to login
	 */

	public long calculateTime() {

		long timeAtAccountLocked = System.currentTimeMillis();
		long timeAtAccountShouldRelease = timeAtAccountLocked + 1800000;
		return timeAtAccountShouldRelease;
	}

	/**
	 * This method is to take account of the attempts when someone is trying to
	 * login if credential provided are correct return success message. if
	 * credentials are incorrect then failed message will be returned. if
	 * someone has tried for 3 time then he will be blocked for 30 minutes
	 * 
	 * @author mayank
	 * @return time at which account should release
	 */
	public String checkAvailableLoginAttempts(String email, String password) {

		if (loginAttempts == 0) {
			if (timeAtAccountShouldRelease < System.currentTimeMillis()) {
				loginAttempts = 3;
			}

		}
		if (loginAttempts > 0) {

			boolean valid = userAuthentication(email, password);

			if (valid) {
				loginAttempts = 3;
				return "Success";
			} else {
				loginAttempts--;
				timeAtAccountShouldRelease = calculateTime();
				return "Failed";
			}
		}
		return "You have Exceeded the number of attempts";

	}

}
