package com.yash.ycmscore.exception;

/**
 * PageUrlNotFoundException extends RuntimeException. This
 * PageUrlNotFoundException is created as unchecked exception and will is thrown
 * when Page Url not found in the database.
 * 
 * @version 0.0.1
 * 
 * Date - 04/11/2018
 * 
 * @author shyam.patidar
 *
 */
public class PageUrlNotFoundException extends RuntimeException {
	/**
	 * This is default serialVersionUID. serialVersionUID is used during
	 * deserialization to verify that the sender and receiver of a serialized
	 * object have loaded classes for that object that are compatible with
	 * respect to serialization.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This is a parameterized constructor which take message as parameter and
	 * forward it to super class.
	 * 
	 * @param message
	 *            This message is the error message displayed with exception
	 */
	public PageUrlNotFoundException(String message) {
		super(message);
	}
}
