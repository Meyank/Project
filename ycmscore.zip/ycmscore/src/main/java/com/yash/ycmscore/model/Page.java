package com.yash.ycmscore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is the Page POJO. This will be used as a data traveler between the
 * different layers of the application this will also work as an entity for
 * database(pages) which contains the information related to domain name which
 * will be created by customer and with domain having static page name with its
 * url stored into database
 * 
 * Date - 04/11/2018
 * 
 * @author yash.verma
 * 
 * @Entity Every persistent POJO class is an entity and is declared using
 *         the @Entity annotation
 * @Table annotation allows you to specify the details of the table that will be
 *        used to persist the entity in the database.
 */
@Entity
@Table(name = "pages")
public class Page {

	/**
	 * This will be the id of the current page
	 * 
	 * @Id declares the identifier property of this entity
	 * @GeneratedValue can be used to define the identifier generation strategy
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotations
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	/**
	 * This is the name of the static page.
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "pageName")
	private String pageName;

	/**
	 * this will be the url or path of the file
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "url")
	private String url;

	/**
	 * this will be the domainName of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "domainName")
	private String domainName;

	/**
	 * a default constructor for Page class.
	 */
	public Page() {
	}

	/**
	 * this will be a parameterized constructor for creation of the objects
	 * 
	 * @param id
	 * @param pageName
	 * @param url
	 * @param doaminName
	 * 
	 */

	public Page(int id, String pageName, String url, String domainName) {
		super();
		this.id = id;
		this.pageName = pageName;
		this.url = url;
		this.domainName = domainName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

}
