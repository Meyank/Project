package com.yash.ycmscore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ycmscore.dao.UserDAO;
import com.yash.ycmscore.model.User;
import com.yash.ycmscore.service.UserService;

/**
 * this is the implementation of the UserService interface
 *
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */
@Service
public class UserServiceImpl implements UserService {

	/**
	 * this is the userDAO bean needed in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * this method will be used to pass a user to the userDAO
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be saved in the database
	 * @return true if user added successfully or false if their is some error
	 *         saving the object
	 */
	public boolean add(User user) {

		return userDAO.add(user);

	}

	/**
	 * this method will be used to pass the user to the userDAO to be updated in
	 * the database
	 * 
	 * @author ishan.juneja
	 * @param user
	 *            to be updated
	 * @return true if update is successful or false if the update is
	 *         unsuccessful
	 */
	public boolean update(User user) {

		return userDAO.update(user);

	}

	/**
	 * this method will be used to pass the id of the user to be deleted to the
	 * userDAO
	 * 
	 * @author ishan.juneja
	 * @param id
	 *            of the user to be deleted
	 * @return true if delete operation is successful and false if delete
	 *         operation is unsuccessful
	 */
	public boolean delete(int id) {

		return userDAO.delete(id);

	}

	/**
	 * this method will return a list of all the users in the database
	 * 
	 * @author ishan.juneja
	 * @return a list of all the users in the database
	 */
	public List<User> list() {

		return userDAO.list();

	}

}
