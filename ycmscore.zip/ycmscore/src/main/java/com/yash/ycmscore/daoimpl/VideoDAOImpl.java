package com.yash.ycmscore.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.VideoDAO;
import com.yash.ycmscore.model.Video;

/**
 * This method provides implementation of the methods present in VideoDAO <br>
 * <br>
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 * @Repository annotation is used in your DAO layer and annotates classes that
 *             perform Database tasks
 *
 */
@Repository
public class VideoDAOImpl implements VideoDAO {

	Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	SessionFactory sessionFactory;

	/**
	 * Save the details of the video into the database
	 * 
	 * @author harmeet.saluja
	 * @param video
	 *            video whose details are to be saved into the database
	 * @return true if the details are saved successfully, else returns false
	 */
	public boolean saveVideoDetails(Video video) {
		Session session = sessionFactory.openSession();
		log.info("Session Created:" + session);
		session.beginTransaction();
		Integer result = (Integer) session.save(video);
		session.getTransaction().commit();
		log.info("Transaction Completed");
		session.close();
		log.info("Session closed:" + session);
		return result != null;
	}

	/**
	 * This method gets the details of all the videos that are present in the
	 * database.
	 * 
	 * @author harmeet.saluja
	 * @return The list of Videos
	 * @SuppressWarnings Instructs the compiler to ignore or suppress the
	 *                   specified compiler warning
	 */
	@SuppressWarnings("unchecked")
	public List<Video> videosList() {
		Session session = sessionFactory.openSession();
		log.info("Session Created:" + session);
		session.beginTransaction();
		List<Video> videosList = null;
		try {
			videosList = session.createQuery("FROM Video").list();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		session.getTransaction().commit();
		log.info("Transaction Completed");
		session.close();
		log.info("Session closed:" + session);
		return videosList;
	}

}
