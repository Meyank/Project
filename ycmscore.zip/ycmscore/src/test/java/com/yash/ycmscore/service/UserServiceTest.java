package com.yash.ycmscore.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.ycmscore.daoimpl.UserDAOImpl;
import com.yash.ycmscore.model.User;
import com.yash.ycmscore.serviceimpl.UserServiceImpl;

public class UserServiceTest {

	@Mock
	UserDAOImpl userDAO;

	@InjectMocks
	UserServiceImpl userService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void test_add_method_with_actual_user_object() {

		when(userDAO.add(any(User.class))).thenReturn(true);
		User user = new User();
		assertThat(userService.add(user), is(true));

	}

	@Test(expected = HibernateException.class)
	public void test_add_method_with_null_user_object() {

		doThrow(HibernateException.class).when(userDAO).add(null);
		User user = null;
		userService.add(user);

	}

	@Test
	public void test_update_method_with_actual_user_object() {

		when(userDAO.update(any(User.class))).thenReturn(true);
		User user = new User();
		assertThat(userService.update(user), is(true));

	}

	@Test(expected = HibernateException.class)
	public void test_update_method_with_null_user_object() {

		doThrow(HibernateException.class).when(userDAO).update(null);
		User user = null;
		userService.update(user);

	}

	@Test
	public void test_delete_method_with_correct_id() {

		when(userDAO.delete(1)).thenReturn(true);
		assertThat(userService.delete(1), is(true));

	}

	@Test(expected = HibernateException.class)
	public void test_delete_method_with_incorrect_user_id() {

		doThrow(HibernateException.class).when(userDAO).delete(15);
		userService.delete(15);

	}

	@Test
	public void test_list_method_return_list_of_users() {

		List<User> list = new ArrayList<User>();
		when(userDAO.list()).thenReturn(list);
		assertThat(userService.list(), is(notNullValue()));

	}
	
}
