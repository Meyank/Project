package com.yash.ycmsweb.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.ycmscore.model.Article;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Token;
import com.yash.ycmscore.service.ArticleService;
import com.yash.ycmscore.service.CustomerService;

import io.jsonwebtoken.Claims;

/**
 * this is the Controller that will handle the requests for the Article related
 * resources
 * 
 * Date - 04/16/2018
 * 
 * @author ishan.juneja
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ArticleController {

	@Autowired
	private ArticleService articleService;

	@Autowired
	private CustomerService customerService;

	@RequestMapping(value = "/articles", method = RequestMethod.POST)
	public String createNewArticle(@RequestBody Article article, HttpServletRequest httpRequest) {
		return articleService.createNewArticle(article, getCustomer(httpRequest).getDomainName());
	}

	@RequestMapping(value = "/articles/getarticle/{articlename}", method = RequestMethod.GET)
	@ResponseBody
	public String getDBAvailablity(@PathVariable String articlename, HttpServletRequest httpRequest) {

		List<String> articles = articleService.getAllArticles(getCustomer(httpRequest).getDomainName());

		for (String article : articles) {
			if (articlename.equalsIgnoreCase(article)) {
				return "article exists";
			}
		}

		return "available";
	}

	public Customer getCustomer(HttpServletRequest httpRequest) {
		Token token = null;
		Customer customer = null;
		Claims claims = (Claims) httpRequest.getAttribute("claims");
		ObjectMapper mapper = new ObjectMapper();
		try {
			token = mapper.readValue(claims.getSubject(), Token.class);
			customer = customerService.getCustomer(token.getEmail());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}

	@RequestMapping(value = "/articles/article/image", method = RequestMethod.POST, consumes = {"multipart/form-data" })
	public void getImage(@RequestParam MultipartFile file) {
		
		Path rootLocation = Paths
				.get("D:\\finalprojectws\\YCMS-cli\\src\\assets\\images");
		try {
			Files.copy(file.getInputStream(), rootLocation.resolve(file.getOriginalFilename()));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	@RequestMapping(value = "searchArticles", method = RequestMethod.POST)
	public List<Article> searchHandler(@RequestBody Article article, HttpServletRequest httpRequest) {
	
		return articleService.getListOfArticles(article,getCustomer(httpRequest).getDomainName());

	}

	@RequestMapping(value = "changeStatusToUntrash", method = RequestMethod.POST)
	public boolean changeTrashedStatusToUntrashed(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToUntrashStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	@RequestMapping(value = "changeStatusToUnpublish", method = RequestMethod.POST)
	public boolean changePublishedStatusToUnpublish(@RequestBody Article article, HttpServletRequest httpRequest) {
		System.out.println(article.getId());
		return articleService.changeStatusToUnpublishStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "changeStatusToTrash", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToTrash(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToTrashStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "changeStatusToFeature", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToFeature(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToFeatured(article.getId(), getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "changeStatusToUnfeature", method = RequestMethod.POST)
	public boolean changeUntrashedStatusToUnfeature(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.changeStatusToUnFeatured(article.getId(), getCustomer(httpRequest).getDomainName());

	}

	@RequestMapping(value = "deleteArticle", method = RequestMethod.POST)
	public int deleteArticle(@RequestBody Article article, HttpServletRequest httpRequest) {

		return articleService.deleteArticle(article.getId(), getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "changeStatusToPublish", method = RequestMethod.POST)
	public boolean changeUnpublishStatusToPublish(@RequestBody Article article, HttpServletRequest httpRequest) {
		System.out.println(article.getId());
		return articleService.changeStatusToPublishStatus(article.getId(), getCustomer(httpRequest).getDomainName());

	}
	
	@RequestMapping(value = "getUntrashedArticles", method = RequestMethod.GET)
	public List<Article> getAllUntrashedArticles(HttpServletRequest httpRequest) {
		System.out.println("getAllUntrashedArticles---->"+getCustomer(httpRequest).getDomainName());		
		return articleService.getAllUntrashedArticles(getCustomer(httpRequest).getDomainName());

	}
}
