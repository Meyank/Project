/**
 * Customer represents the user of the application.
 * 
 * Author : maithili.pande
 */
export class Customer{
    /**
     * represents customer's unique indentifier
     */
    id:number;

    /**
     * represents customer's organization name
     */
    organization:string;

    /**
     * represents first name
     */
    firstName:string;

    /**
     * represents last name
     */
    lastName:string;

    /**
     * represents email
     */
    email:string;

    /**
     * represents contact
     */
    contact:string;

    /**
     * represents address
     */
    address:string;

    /**
     * represents country
     */
    country:string;

    /**
     * represents state
     */
    state:string;

    /**
     * represents city
     */
    city:string;

    /**
     * represents zip
     */
    zip:number;

    /**
     * represents last Login date
     */
    lastLoginDate:Date;

    /**
     * represents last login time
     */
    lastLoginTime:Date;
    
    /**
     * the "constructor".
     * @param id 
     * @param organization
     * @param firstName 
     * @param lastName 
     * @param email 
     * @param contact 
     * @param address
     * @param country 
     * @param state
     * @param city
     * @param zip
     * @param lastLoginDate
     * @param lastLoginTime
     */
    constructor( id:number,organization:string,firstName:string,lastName:string,
                 email:string,contact:string,address:string,country:string,state:string,
                city:string,zip:number,lastLoginDate:Date,lastLoginTime:Date){
    this.id=id;
    this.organization=organization;
    this.firstName=firstName;
    this.lastName=lastName;
    this.email=email;
    this.contact=contact;
    this.address=address;
    this.country=country;
    this.state=state;
    this.city=city;
    this.zip=zip;
    this.lastLoginDate;
    this.lastLoginTime;
    };
 
}

