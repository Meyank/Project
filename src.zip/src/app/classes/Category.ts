export class Category{
    id:number
    title:string
    status:number
    alias:string
    access:number
    trash:number
    description:String
    archive:number
    parentCategory:string
    language:string
}