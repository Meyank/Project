import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './routing/app-routing.module';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxEditorModule } from 'ngx-editor';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { CustomerdashboardComponent } from './components/customerdashboard/customerdashboard.component';
import { AdminportalComponent } from './components/adminportal/adminportal.component';
import { HomeComponent } from './components/home/home.component';
import { GettingStartedComponent } from './components/getting-started/getting-started.component';
import { ManageYcmsComponent } from './components/manage-ycms/manage-ycms.component';
import { MyaccountComponent } from './components/myaccount/myaccount.component';
import { UpdateComponent } from './components/update/update.component';
import { VideoComponent } from './components/video/video.component';
import { WhatsNewComponent } from './components/whats-new/whats-new.component';
import { YcmsVideoTutorialComponent } from './components/ycms-video-tutorial/ycms-video-tutorial.component';
import { EditorComponent } from './components/editor/editor.component';
import { ListcategoriesComponent } from './components/listcategories/listcategories.component';
import { batchinfo } from './components/common/footer/batchinfo/batchinfo.component';

import { LoginService } from './services/login/login.service';
import { RegistrationService } from './services/registration/registration.service';
import { AdminportalService } from './services/adminportal/adminportal.service';
import { CustomerdashboardService } from './services/customerdashboard/customerdashboard.service';
import { HomeService } from './services/home/home.service';
import { VideoService } from './services/video/video.service';
import { WhatsNewService } from './services/whats-new/whats-new.service';
import { EditorService } from './services/editor/editor.service';
import { AuthService } from './interceptors/auth.service';
import { ListArticleService } from './services/listarticle/list-article.service';
import { ListService } from './services/listCategories/list.service';
import { CategoryService } from './services/createcategory/category.service';
import { LogoutService } from './services/logout/logout.service';

import { AdminsidebarComponent } from './components/sidebar/adminsidebar/adminsidebar.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { HeaderComponent } from './components/common/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppMaterialModule } from './app-material/app-material.module';
import { AdminnavbarComponent } from './components/navbars/adminnavbar/adminnavbar.component';
import { YcmsTutorialComponent } from './components/ycms-tutorial/ycms-tutorial.component';
import { ListArticleComponent } from './components/list-article/list-article.component';
import { CategoryComponent } from './components/category/category.component';

import { AliasNamePipe } from './pipes/aliasName';
import { LowerCasePipe } from '@angular/common';
import { DialogBoxComponent } from "./components/list-article/dialog-box/dialog-box.component";
import { DataService } from './services/data/data.service';

import { EditorModule } from '@tinymce/tinymce-angular';

import { HostURL } from './hostUrl/hostUrl';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { PortfolioService } from './services/portfolio/portfolio.service';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    CustomerdashboardComponent,
    AdminportalComponent,
    AdminsidebarComponent,
    FooterComponent,
    HeaderComponent,
    AdminnavbarComponent,
    HomeComponent,
    GettingStartedComponent,
    ManageYcmsComponent,
    MyaccountComponent,
    UpdateComponent,
    VideoComponent,
    WhatsNewComponent,
    YcmsVideoTutorialComponent,
    YcmsTutorialComponent,
    EditorComponent,
    ListArticleComponent,
    ListcategoriesComponent,
    CategoryComponent,
    AliasNamePipe,
    DialogBoxComponent,
    batchinfo,
    PortfolioComponent,

  ],
   entryComponents: [
    DialogBoxComponent,
    batchinfo
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AppMaterialModule,
    HttpModule,
    HttpClientModule,
    NgxEditorModule,
	EditorModule,
    TooltipModule.forRoot()
  ],
  providers: [
    LoginService,
    RegistrationService,
    CustomerdashboardService,
    AdminportalService,
    HomeService,
    VideoService,
    DataService,
    WhatsNewService,
    ListArticleService,
    ListService,
    CategoryService,
    EditorService,
    WhatsNewService, 
    ListArticleService,
    ListService,
    CategoryService,
    LogoutService,
    HostURL,
    EditorService, {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthService,
      multi: true
    },
    AliasNamePipe,
    LowerCasePipe,
    ListArticleService,
    EditorService,
    PortfolioService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
