import { Component, OnInit } from '@angular/core';
import {Observable}  from 'rxjs/Observable'
import {LoginService} from '../../services/login/login.service';
import { Router } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { DataService } from '../../services/data/data.service';
import {HeaderComponent} from '../common/header/header.component'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  email:string;
  password:string;
  error=false;
  currentLoginValue:boolean;
  headers;
  clicked:boolean=false;
  constructor(private router:Router, 
              private dataService:DataService,
              private LoginService:LoginService) { }

    signInCustomer(){
      this.clicked=true;
      this.LoginService.checkIfUsernameAndPasswordIsValid(this.email,this.password).subscribe(
        (res:HttpResponse<any>)=>{
          console.log(res);
          sessionStorage.setItem('Authorization',res.headers.get('authorization'));
          this.changeLoginValue();
          this.router.navigateByUrl('/customerDashboard');
        },
        err=>{
          this.clicked=false;
          this.error=true;
          console.log(err);
        },
        
      )
    }
    ngOnInit() {
      
    }


    changeLoginValue() {
      this.dataService.currentLoginValue.subscribe(currentLoginValue => this.currentLoginValue = currentLoginValue );
      this.changeValue();
    }

    changeValue() {
    this.dataService.changeLoginValue(true);
    }
    
    

}
