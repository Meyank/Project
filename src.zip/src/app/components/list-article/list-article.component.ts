import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator,MatDialog } from '@angular/material';
import { Article } from '../../classes/article';
import { Router } from '@angular/router';
import { ListArticleService } from '../../services/listarticle/list-article.service';
import { FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { DialogBoxComponent } from "./dialog-box/dialog-box.component";
import { HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-list-article',
  templateUrl: './list-article.component.html',
  styleUrls: ['./list-article.component.css']
})

/**
 * this will work as a mediator in between service and html component.
 * 
 * @author saloni.jain
 * 
 */
export class ListArticleComponent implements OnInit {
 
/** array Of publish status**/   
publishStatus = [
    {value: 'Published', viewValue: 'Published'},
    {value: 'Unpublished', viewValue: 'Unpublished'},
  ];

  dialogData: any;
  animal: string;
  name: string;



  openDialog(): void {
      let dialogRef = this.dialog.open(DialogBoxComponent, {
      
      data: { name: this.name, animal: this.animal }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }

   /**

  /** array Of access**/   
accessStatus = [
  {value: 'Private', viewValue: 'Private'},
  {value: 'Public', viewValue: 'Public'},
];

/** array Of feature status**/   
featureStatus = [
  {value: 'Feature', viewValue: 'Featured'},
  {value: 'Unfeature', viewValue: 'Unfeatured'},
];

/** array Of feature status**/   
languages = [
  {value: 'en', viewValue: 'en'},
  {value: 'hi', viewValue: 'hi'},
];

  /**
   * this variable value will decide to show the span
   */
  private showSpanOnClick:boolean = false;
  /**
   * This varialble value will decide to show side navigation span.
   */
  private showsideNavigationSpanOnClick:boolean=false;
   /**
   * this will store the value of file
   */
  private fileName:string ='';
  /**
   * this will store  the value of status i.e. published or unpublished
   */
  private selectedStatus:string ='';
  /**
   * this will store  the value of access i.e. public or private
   */
  private selectedAccess:string ='';
  /**
   * this will store the value of feature i.e. feature or unfeature
   */
  private selectedFeature:string="";
  /**
   * this will store  the value of author name
   */
  private author:string='';
  /**
   * this will store the value of access
   */
  private access:string='';
  /**
   * this will store the value of language
   */
  private language:string='';
  /**
   * this will store the value of id
   */
  private id:number;
  /**
   * this will store the value of text to be search
   */
  private searchText:string="";
  /**
   * this vairiable's value will decide whether the message box will appear or not
   */
  private showMessage:boolean=false;
  /**
   * this will store the value of tag.
   */
  private tag:string="";
  /**
   * this will store the name of coloumns
   */
  displayedColumns = ['moreVert','checkbox','status','title','access', 'author', 'language','dateCreated','hits','id','edit-button'];
  dataSource: MatTableDataSource<Article>;

  // @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  /**
   * this will recieve the value in form of JSON
   */
   articles: Article[] = [];
  /**
   * 
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   * 
   *  @param listArticleService is injected
   */
  constructor(private listArticleService : ListArticleService, 
              private router: Router,
              public dialog: MatDialog) {
	  if(sessionStorage.getItem('Authorization')===null){
	  this.router.navigate(['/signin']);
	  }
				  
    // Assign the data to the data source for the table to render
    this.listArticleService.getAllArticles().subscribe(
	
      (res:Article[])=>{
		  
		  console.log(res);
         this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
      },
      err=>{
        console.log(err);
      }
    );
    
  }
  ngOnInit() {
    
  }
  /**
   * this method will show the search Toolbar.
   */
  showSpan(){
    this.showSpanOnClick=!this.showSpanOnClick;
  }

  showSideNavigationSpan(){
    this.showsideNavigationSpanOnClick=!this.showsideNavigationSpanOnClick;
  }
  
  /**
   * this will clear the data of all textbox
   */
  clearTextBox(){
  this.searchText="";
   this.fileName="";
   this.selectedStatus="";
   this.selectedAccess="";
   this.selectedFeature="";
   this.author="";
   this.language="";
   this.tag="";
   this.id=0;
   this.getListOfUntrashedArticles();
  }

 
  ngAfterViewInit() {
    
  }
  /**
   * This method will filter the list of articles.
   * @param filterValue is value on the basis of which we will filter
   * the list of articles.
   */
  applyFilter(filterValue:string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }


/** this function will builds and returns a list of articles. */
  getListOfArticles(){ 
    console.log(this.selectedStatus);
  this.listArticleService.getListOfArticles(this.fileName,this.selectedStatus,this.selectedAccess,this.author,this.language,this.id).subscribe(
  res=>{ 
    this.dataSource = new MatTableDataSource(JSON.parse(JSON.stringify(res)));
    this.dataSource.paginator = this.paginator;
  },
  err=>{
  console.log(err);
  }
  ); 
  }

  getListOfUntrashedArticles() {
    this.listArticleService.getAllArticles().subscribe(
      res=>{
        this.dataSource = new MatTableDataSource(JSON.parse(JSON.parse(JSON.stringify(res))._body));
        this.dataSource.paginator = this.paginator;
      },
      err=>{
        console.log(err);        
      }
    );
  }
  /**
   * method that will used to set Id.
   */
  changeId(id:number){
    this.id=id;
  }


  createNewArticle(){
    this.router.navigate(['newArticle']);  
  }


  editArticle(fileName:string){
    console.log(fileName);
	this.listArticleService.editArticle(fileName).subscribe(
	res=>{
		console.log(res);
		localStorage.setItem('htmlContent',res.htmlContent);
		localStorage.setItem('title',res.fileName);
		localStorage.setItem('publish',res.publishStatus);
		localStorage.setItem('featured',res.featureStatus);
		localStorage.setItem('tags',res.tag);
		localStorage.setItem('category',res.category);
		localStorage.setItem('language',res.language);
		localStorage.setItem('access',res.access);
		
		this.router.navigate(['/newArticle']);
	},
	err=>{
		console.log(err.error.text.htmlContent);

	}
	);
  }


  changeStatusToPublish(id:number){
    this.listArticleService.changeStatusToPublish(this.id).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
  changeStatusToUnpublish(){
    this.listArticleService.changeStatusToUnpublish(this.id).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
  changeStatusToFeatureArticle(){
    this.listArticleService.changeStatusToFeatureArticle(this.id).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
    
  }
  changeStatusToUnfeatureArticle(){
    this.listArticleService.changeStatusToUnfeatureArticle(this.id).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
  deleteArticle(){
    console.log("feature new article",this.id);
    this.listArticleService.deleteArticle(this.id).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
  getAllTrashArticles(){
    this.listArticleService.getAllTrashArticles().subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
  
  openPage(title:string){
	 this.listArticleService.openPage(title).subscribe(
	 (res:HttpResponse<any>)=>{
		 console.log(res);
	 },
	 err=>{
		 console.log(err);
		 let url = err.error.text;
		 window.open(url);
	 }
	 
	 );
  }


}
