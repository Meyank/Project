import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../../services/createcategory/category.service';
import { ListService } from '../../services/listCategories/list.service';
import { Category } from '../../classes/Category';
import { AliasNamePipe } from '../../pipes/aliasName';
import { LowerCasePipe } from '@angular/common';
import { Router } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http'
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
/**
 * this component creates a category 
 * Author :  minerva.shrivastava
 */
export class CategoryComponent implements OnInit {

  /**
   * the properties of Category
   */
  categoryTitle : string;
  categoryDescription : string;
  categoryAlias : string;
  parentCategory : string;
  message : string;
  categoryStatus: number;
  categoryAccess: number;
  categoryLanguage : string;
  category : Category = new Category();
  categoryList : Category[];
  isParentCategory : boolean;

  statuses = [
    { value: '0', viewValue: 'Published' },
    { value: '1', viewValue: 'Unpublished' },
  ];

  categories = [
    { value: 'about', viewValue: 'About' },
    { value: 'info', viewValue: 'Info' },
  ];

  accesses = [
    { value: '0', viewValue: 'Public' },
    { value: '1', viewValue: 'Private' },
  ];

  languages = [
    { value: 'EN', viewValue: 'English' },
    { value: 'HI', viewValue: 'Hindi' },
  ];

  /**
   * Custructor initializing category service , 
   * aliasNamePipe and lowerCasePipe
   * @param categoryService 
   * @param aliasNamePipe 
   * @param lowerCasePipe 
   */
  constructor(private categoryService : CategoryService,
              private listService : ListService,
              private aliasNamePipe : AliasNamePipe,
              private lowerCasePipe : LowerCasePipe,
              private router : Router,
              public snackBar: MatSnackBar
              ) {
				  if(sessionStorage.getItem('Authorization')===null){
				  this.router.navigate(['/signin']);
				}
			  }
  
  /**
   * this method takes the selected value of the drop down 
   * and sets the value in parent property of Category
   * @param event - click event of Parent drop down
   */
  parentSelect(event){
    this.category.parentCategory = event.target.value;
  }

  /**
   * this method takes the selected value of the drop down 
   * and sets the value in status property of Category
   * @param event - click event of status drop down
   */
 statusSelect(event){
    this.category.status = event.target.value;
    console.log(this.category.status);
  }

  /**
   * this method takes the selected value of the drop down 
   * and sets the value in access property of Category
   * @param event - click event of access drop down
   */
  accessSelect(event){
    this.category.access = event.target.value;
  }

  /**
   * this method takes the selected value of the drop down 
   * and sets the value in language property of Category
   * @param event - click event of language drop down
   */
  languageSelect(event){
    this.category.language = event.target.value;
  }

  ngOnInit() {
      this.getAllCategories();
  }

  /**
   * this method calls the addCategory method of category service and 
   * adds the Category with all the properties obtained 
   */
  addCategory(){
    this.category.title = this.categoryTitle;
    this.category.description = this.categoryDescription;
    if(this.categoryTitle){
      this.category.alias = this.lowerCasePipe.transform(this.aliasNamePipe.transform(this.categoryTitle));
      //console.log("After applying pipe :",this.category.alias);
    }
    this.category.status = this.categoryStatus;
    this.category.parentCategory = this.parentCategory;
    this.category.access = this.categoryAccess;
    this.category.language = this.categoryLanguage;

     this.categoryService.addCategory(this.category).subscribe(
     
        (res: HttpResponse<any>) => {
          console.log(res);
        }
        ,
        (err: HttpErrorResponse) => {
          console.log(err);
          this.message = err.error.text;
          this.snackBar.open(this.message, 'Done', { duration: 2000 });
        }
        )
     }

  saveAndClose() {
    this.addCategory();
    //this.router.navigateByUrl('listCategories');
  }

  saveAndNew() {
    this.addCategory();
    window.location.reload();
  }

  cancel() {
    this.router.navigateByUrl('customerDashboard/adminPortal');
  }

  getAllCategories() {
    this.listService.getAllCategories(0).subscribe( 
      res=>{
        this.categoryList = JSON.parse(JSON.stringify(res));
        console.log(this.categoryList)
      },
      err=>console.log(err)
    )
  }
  listButton(){
    console.log("list button working");
  }
}
