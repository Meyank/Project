import { Component, OnInit, ViewChild } from '@angular/core';
import {Category} from '../../classes/Category';
import { ListService } from '../../services/listCategories/list.service';
import {MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listcategories',
  templateUrl: './listcategories.component.html',
  styleUrls: ['./listcategories.component.css']
})
export class ListcategoriesComponent implements OnInit {

  categories:Category[];
  dataSource:MatTableDataSource<any>;
  showsideNavigationSpanOnClick:boolean=false;

  constructor(private listservice:ListService,private router:Router) {
	  if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
	  
    this.getDataFromDatabase();
   }
  displayedColumns = ['drag', 'checkbox', 'Title', 'Publish', 'Unpublish','Archive','Trash', 'Access', 'Language', 'id'];
  

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort:MatSort;

  ngOnInit() {
  }

  showSideNavigationSpan(){
    this.showsideNavigationSpanOnClick=!this.showsideNavigationSpanOnClick;
  }

  updateTrash(id:number){
    this.listservice.updateTrashById(id).subscribe(
      res=>{
        this.getDataFromDatabase();
      },err=>{
        console.log(Error)
      }
    )

  }

  getDataFromDatabase(){
    this.listservice.getAllCategories(0).subscribe(
      res=>{
        this.categories=JSON.parse(JSON.stringify(res));
        this.dataSource = new MatTableDataSource(this.categories);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      err=>console.log(Error)
    )
  }
  
  getDataFromTrash(){
    this.listservice.getAllCategories(1).subscribe(
      res=>{
        this.categories=JSON.parse(JSON.stringify(res));
        this.dataSource = new MatTableDataSource(this.categories);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      err=>console.log(Error)
    )
  }

}