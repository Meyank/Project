import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-ycms-video-tutorial',
  templateUrl: './ycms-video-tutorial.component.html',
  styleUrls: ['./ycms-video-tutorial.component.css']
})
export class YcmsVideoTutorialComponent implements OnInit {

  constructor(private router:Router) { 
  
	if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
  }

  ngOnInit() {
  }

}
