import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YcmsVideoTutorialComponent } from './ycms-video-tutorial.component';

describe('YcmsVideoTutorialComponent', () => {
  let component: YcmsVideoTutorialComponent;
  let fixture: ComponentFixture<YcmsVideoTutorialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YcmsVideoTutorialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YcmsVideoTutorialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
