import { Component, OnInit } from '@angular/core';
import { PortfolioService } from '../../services/portfolio/portfolio.service';
@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {

  constructor(private portfolioService:PortfolioService) { }

  selectedFiles;
  currentFileUpload;
  name='';
  secondaryname='';
  title='';
  facebook='';
  instagram='';
  github='';
  
  
  ngOnInit() {
  }
  
  selectFile(event) {
  this.selectedFiles = event.target.files;
	console.log(this.selectedFiles.item(0));
  }

  upload() {
    var title = document.getElementById("title");
    this.currentFileUpload = this.selectedFiles.item(0)
    this.portfolioService.uploadInformation(this.currentFileUpload,this.title,this.name,this.secondaryname,this.facebook,this.instagram,this.github).subscribe(
      res => {
        console.log(res);
      },
      error => {
        console.log(error)
      }
    );
    this.selectedFiles = undefined;
  }

}
