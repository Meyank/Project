import { Component, OnInit } from '@angular/core';
import { Video } from '../../classes/video';
import { VideoService } from '../../services/video/video.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.css']
})
export class VideoComponent implements OnInit {

  /**
   * video will get the title and path of the current video that will be uploaded.
   */
  video: Video = new Video();

  /**
   * selectedVideo represents the video that is currently displayed.
   */
  selectedVideo: Video;

  /**
   * selectedFiles represents the list of file thta is currently selected.
   */
  selectedFiles: FileList;

  /**
   * currentFileUpload represents the file that is currently uploaded.
   */
  currentFileUpload: File;

  /**
   * basePath represents the relative path where the video will be saved.
   */
  basePath = "assets/videos/";

  /**
   * The list of video details
   */
  videosList: Video[];

  /**
   * constructor of the class
   * 
   * @param videoService videoService is used to execute the methods of videoService 
   */
  constructor(private videoService: VideoService,private router:Router) { 

  if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
  }

  /**
   * This method is used to perform the initialization logic that will be required
   */
  ngOnInit() {
    this.getAllVideos();
  }

  /**
   * This method runs when any file is selected from the html file.
   * 
   * @param event onChange event executed when the file is selected.
   */
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  /**
   * This method calls the method of VideoService to upload the file.
   */
  upload() {
    var title = document.getElementById("title");
    console.log(this.video['title']);
    this.currentFileUpload = this.selectedFiles.item(0)
    this.videoService.uploadVideo(this.currentFileUpload, this.video['title']).subscribe(
      res => {
        window.location.reload();
      },
      error => {
        console.log(error)
      }
    );
    this.selectedFiles = undefined;
  }

  /**
   * This method calls the method of VideoService and gets the details of all the videos.
   */
  getAllVideos() {
    this.videoService.getAllVideos().subscribe(
      res => {
        this.videosList = res;
        this.videosList.forEach(video => {
          console.log(video['title'] + ':' + video['path']);
          video['path'] = this.basePath + video['path'];
          console.log(video['path']);
        },
          error => {
            console.log("Error" + error);
          }
        );
      }
    );
  }

  /**
   * This method is used to set the selectedVideo that will be displayed.
   * 
   * @param selectedVideo 
   */
  setVideo(selectedVideo: Video) {
    console.log(selectedVideo);
    this.selectedVideo = new Video();
    this.selectedVideo = selectedVideo;
    let element = document.getElementById("videoToBeDisplayed");
    if (element != undefined) {
      element.setAttribute("src", selectedVideo['path']);
    }
    console.log(element);
    console.log()
  }


}
