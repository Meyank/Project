import { Component, OnInit, ViewChild, AfterViewInit,EventEmitter } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateComponent } from '../update/update.component';
import { DataService } from '../../services/data/data.service';
import { Customer } from '../../classes/customer';

@Component({
  selector: 'app-customerdashboard',
  templateUrl: './customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})
export class CustomerdashboardComponent implements OnInit {
  

 /**
   *  checks selection for tabs, set to false when tab is selected
   */
  condition = true;
  
  /**
   * 
   */
  check:boolean=false;
  customer:Customer;
  constructor(private router:Router, private data: DataService) {
      // if(sessionStorage.getItem('Authorization')===null){
      //   this.router.navigateByUrl('signin') 
      // }
  }
  /**
   * @ignore
   */
  ngOnInit(){
    
   }



  /**
   * subscribe to checkEvent that’s outputted by the child component ie UpdateComponent, 
   * then run the assignmentValue function whenever this event occurs.
   * @param event 
   */
  assigneventValue(event){
    this.check=event;
  }

  /**
   * sets the condition property to false
   */
  tabSelection() {
    this.condition=false;
  }

}
