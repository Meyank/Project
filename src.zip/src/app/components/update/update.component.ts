import { Component, OnInit, Input, Output, OnChanges, EventEmitter } from '@angular/core';
import { CustomerdashboardService } from '../../services/customerdashboard/customerdashboard.service';
import { Customer } from '../../classes/customer';
import { NgModel } from '@angular/forms';
import { HttpResponse,HttpErrorResponse } from '@angular/common/http'
import { DataService } from '../../services/data/data.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
/**
 * This component is responsible for updating customer's profile details.
 * 
 * Author : maithili.pande
 */
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})

export class UpdateComponent implements OnInit {
  /**
   * locally stores id of customer
   */
  id: number;

  /**
   * organisation is two-way binding property for input tag for organization
   */
  organization: string;

  /**
   * firstName  is two-way data binding property for input tag for firstName
   */
  firstName: string;

  /**
   * lastName is two-way data binding property for input tag for lastName
   */
  lastName: string;

  /**
   * email is two-way data binding property for input tag for email
   */
  email: string;

  /**
   *contact is two-way data binding property for input tag for contact
   */
  contact: string;

  /**
   * address is two-way data binding property for input tag for address
   */
  address: string;

  /**
   * country is two-way binding property for input tag for country
   */
  country: string;

  /**
   * state is two-way binding property for input tag for state
   */
  state: string;

  /**
   * city is two-way binding property for input tag for city
   */
  city: string;

  /**
   * zip is two-way binding property for input tag for zip
   */
  zip: number;
  
  /**
     * represents last Login date
     */
    lastLoginDate:Date;

    /**
     * represents last login time
     */
    lastLoginTime:Date;

  /**
   * temporarily holds customer object.
   */
  customer= new Customer(this.id,this.organization,this.firstName,this.lastName,this.email,this.contact,
            this.address,this.country,this.state,this.city,this.zip,this.lastLoginDate,this.lastLoginTime);
    
   
constructor(private customerService:CustomerdashboardService, public snackBar: MatSnackBar,private router:Router){
	
	if(sessionStorage.getItem('Authorization')===null){
		  this.router.navigate(['/signin']);
	  }
	
}

  /**
   * variable to check if update form fields are empty 
   */
  check: boolean;
  /**
   * used to share data from the child ie Updatecomponent, 
   * which can be listed by the parent ie CustomerDashboardComponent.
   */
  @Output() checkEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
   /**
   * this is an array which represents country name
   */
  countryNames = [
    { viewValue: 'India' },
    { viewValue: 'Germany' },
    { viewValue: 'US' }
  ];

  /**
   * this is an array which represents state name
   */
  stateNames = [];

  /**
   * calls getCustomer method from service class to fetch customer details.
   */

  
  ngOnInit() {
    this.customerService.getCustomer(this.email).subscribe(
      (res: HttpResponse<any>) => {
      
        this.customer = JSON.parse(JSON.stringify(res)).body;
        this.countryDropDownChanged(this.customer['country']);
        console.log(this.customer);
      this.checkIfNull();
      },
      (error:HttpErrorResponse) => {
      }
    );
  
  }


  /**
   * calls updateCustomer method from service to update customer profile details.
   */
  updateCustomer() {
    console.log(this.customer);
    this.customerService.updateCustomer(this.customer).subscribe(
      (res: HttpResponse<any>) => {
        this.customer = JSON.parse(JSON.stringify(res)).body;
        this.snackBar.open('Profile Updated Successfuly', 'done', { duration: 2000 });
        this.checkIfNull();

      },
      (error:HttpErrorResponse) => {
      }
    )
  }

  /**
   * this function is called when country is changed and on basis of changed value, states are changed
   * @param value is changed value of country
   */
  countryDropDownChanged(value) {
    if(value === 'India') {
      this.stateNames = [
        { viewValue: 'Madhya Pradesh' },
        { viewValue: 'Maharashtra' },
        { viewValue: 'Rajasthan' }
      ];
    }
    else if (value === 'Germany') {
      this.stateNames = [
        { viewValue: 'Berlin' },
        { viewValue: 'Hamburg' },
        { viewValue: 'Bremen' }
      ];
    }
    else if (value === 'US') {
      this.stateNames = [
        { viewValue: 'Boston' },
        { viewValue: 'Oklahama' },
        { viewValue: 'Texas' }
      ];
    }
    else {
      this.stateNames = [];
    }
  }

  /**
   * checks if form fields are null.
   * Assigns true if form fields are null, assigns false if all the form fields are filled
   */
  checkIfNull(): void {
    if(this.customer.organization === '' || this.customer.address === '' || this.customer.city === '' ||
      this.customer.contact === '' || this.customer.firstName === '' || this.customer.lastName === '' ||
      this.customer.state === '' || this.customer.zip == null) {
      this.check = true;
      this.checkEvent.emit(this.check);
    }
    else {
      this.check = false;
      this.checkEvent.emit(this.check);
    }
  }

}
