import {Component, Inject} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
    selector: 'app-batchinfo',
    templateUrl: './batchinfo.component.html',
    styleUrls:['./batchinfo.component.css']
  })
  export class batchinfo {
  
    constructor(
      public dialogRef: MatDialogRef<batchinfo>) { }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
  
  }