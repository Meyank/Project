import { Component, OnInit, AfterViewInit } from '@angular/core';
import { DataService } from '../../../services/data/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements AfterViewInit {

  
  currentLoginValue:boolean=false;

  constructor(private dataService : DataService,private router: Router) { 

  }

  loggedin=false;

changeStatus(){
this.loggedin=!this.loggedin;
}

  ngOnInit() {
    
  }

  ngAfterViewInit(){
    this.dataService.currentLoginValue.subscribe(currentLoginValue => this.currentLoginValue = currentLoginValue)
  }
  changeLogoutValue() {
    this.dataService.currentLoginValue.subscribe(currentLoginValue => this.currentLoginValue = currentLoginValue );
    this.changeValue();
  }

  changeValue() {
  this.dataService.changeLoginValue(false);
  sessionStorage.removeItem('Authorization');
  this.router.navigate(['/signin']);
  }
  
  home(){
	  this.router.navigate(['customerDashboard/adminPortal']);
  }
  
}
