import { Component, OnInit } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { EditorService } from '../../services/editor/editor.service'
import { Router } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http'
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent implements OnInit {

  constructor(private router: Router, private editorservice: EditorService, public snackBar: MatSnackBar) { 
  
  if(sessionStorage.getItem('Authorization')===null){
	  this.router.navigate(['/signin']);
	  }
  
  if(localStorage.getItem('title')!=null){
  this.htmlContent= localStorage.getItem('htmlContent');
  this.title=localStorage.getItem('title');
  this.status=localStorage.getItem('publish');
  this.featured=localStorage.getItem('featured');
  this.tags=localStorage.getItem('tags');
  this.category=localStorage.getItem('category');
  this.language=localStorage.getItem('language');
  this.access=localStorage.getItem('access');
  
  localStorage.removeItem('htmlContent');
  localStorage.removeItem('title');
  localStorage.removeItem('publish');
  localStorage.removeItem('featured');
  localStorage.removeItem('tags');
  localStorage.removeItem('category');
  localStorage.removeItem('language');
  localStorage.removeItem('access');
  }
    
  }

  htmlContent: String = '';
  title: String = '';
  alias: String = '';
  featured: String = ''
  tags: String = '';
  status: String = '';
  category: String = '';
  access: String = '';
  language: String = '';
  author:String='';
  message: string = '';


  statuses = [
    { value: 'published', viewValue: 'Published' },
    { value: 'unpublished', viewValue: 'Unpublished' },
  ];

  categories = [
    { value: 'uncategorised', viewValue: 'uncategorised' }
  ];

  accesses = [
    { value: 'public', viewValue: 'Public' },
    { value: 'private', viewValue: 'Private' },
  ];
  languages = [
    { value: 'EN', viewValue: 'English' },
    { value: 'HI', viewValue: 'Hindi' },
  ];


  save() {
    this.editorservice.save(this.title, this.alias, this.htmlContent, this.featured, this.status, this.category, this.access, this.language, this.tags).subscribe(

      (res: HttpResponse<any>) => {
        console.log(res);
      }
      ,
      (err: HttpErrorResponse) => {
        console.log(err);
        this.message = err.error.text;
        this.snackBar.open(this.message, 'done', { duration: 2000 });
		  document.getElementById('savebutton').setAttribute("disabled", "true");
		  document.getElementById('saveandclose').setAttribute("disabled", "true");
		  document.getElementById('saveandnew').setAttribute("disabled", "true");
      }
    )
  }

  saveascopy() {
    this.editorservice.save(this.title+'(1)', this.alias, this.htmlContent, this.featured, this.status, this.category, this.access, this.language, this.tags).subscribe(

      (res: HttpResponse<any>) => {
        console.log(res);
      }
      ,
      (err: HttpErrorResponse) => {
        console.log(err);
        this.message = err.error.text;
        this.snackBar.open(this.message, 'done', { duration: 2000 });
      }
    )
  }

  saveandclose(){
    this.save();
    this.router.navigateByUrl('listArticles');
  }


  checkTitle() {
    this.editorservice.checkTitle(this.title).subscribe(

      (res: HttpResponse<any>) => {

      }
      ,
      (err: HttpErrorResponse) => {
        if (err.error.text === 'article exists') {
          document.getElementById('savebutton').setAttribute("disabled", "true");
		  document.getElementById('saveandclose').setAttribute("disabled", "true");
		  document.getElementById('saveandnew').setAttribute("disabled", "true");
          this.message = err.error.text;
        }
        else {
          document.getElementById('savebutton').removeAttribute("disabled");
        }

      }
    )
  }
  
  close(){
	  this.router.navigateByUrl('listArticles');
  }

  ngOnInit() {
	  
	  this.editorservice.getCategories().subscribe(
  
  res=>{

	  res.forEach(element => {
      console.log(element.alias);
      this.categories.push({value:element.alias,viewValue:element.alias});
    });
  },
  err=>{
	  console.log(err);
  }
  
  );
	  
  }

}
