import { TestBed, inject } from '@angular/core/testing';

import { CustomerdashboardService } from './customerdashboard.service';

describe('CustomerdashboardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomerdashboardService]
    });
  });

  it('should be created', inject([CustomerdashboardService], (service: CustomerdashboardService) => {
    expect(service).toBeTruthy();
  }));
});
