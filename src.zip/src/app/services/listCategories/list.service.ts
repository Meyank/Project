import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';
@Injectable()
export class ListService {

  constructor(private http:Http,private httpClient:HttpClient,private hosturl:HostURL) { }

  getAllCategories(trashStatus:number){
    let url = "http://"+this.hosturl.hostName+"/ycmsweb/categories/"+trashStatus;
    return this.httpClient.get(url);
  }

  updateTrashById(id:number){
    let url = "http://"+this.hosturl.hostName+"/ycmsweb/categories/trash/"+id;
    return this.httpClient.get(url);
  }

}