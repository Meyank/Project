import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http,Response,Headers,RequestOptions } from '@angular/http';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';
@Injectable()
export class LoginService {

  constructor(private http:HttpClient,private hosturl:HostURL) { }

  checkIfUsernameAndPasswordIsValid(email:string,password:string){
    
    let url="http://"+this.hosturl.hostName+"/ycmsweb/customers/authenticate";
    var customer={"email":email,  "password":password}
    let params = customer;
    
      return this.http.post(url, params, {observe: 'response'});
      }
  }
