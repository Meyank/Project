import { Injectable } from '@angular/core';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';
/** 
 * 
 * @author saloni.jain
 * 
 * this service will return the functionality related to listing of article.
 */
@Injectable()
export class ListArticleService {

  /**
   * @author saloni.jain
   * @param http is injected
   */
  constructor(private httpclient:HttpClient,private hosturl:HostURL) { }

  /**
   * this function will return the list on the basis of attributes provided to it.
   * 
   * @author saloni.jain
   * 
   * @param title is the name of file
   * @param selectedStatus is the status of file i.e it is published or unpublished
   * @param selectedAccess is the status of file i.e it is public or private
   */
  getListOfArticles(name:string,selectedStatus:string,selectedAccess:string , author:string,language:string,id:number){
    let url = 'http://'+this.hosturl.hostName+'/ycmsweb/searchArticles';
    var data={"filename":name,"publishStatus":selectedStatus,"access":selectedAccess,"author":author,"language":language,"id":id};
    let headers = new HttpHeaders({'Content-Type': 'application/json'});
    return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }
    /**
     * 
     * @author saloni.jain
     * 
     * this will return the list of all articles
     */
  getAllArticles(){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/getUntrashedArticles';
      let headers = new Headers({'Content-Type': 'application/json'});
      return this.httpclient.get(url);
    }
    /**
     * 
     * @author saloni.jain
     * 
     * this will change the status of articles from unpublish to publish
     */
    changeStatusToPublish(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToPublish';
       var data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data,{headers: headers, withCredentials : true});
    }
    /**
     * 
     * @author saloni.jain
     * 
     * this will change the status of articles from publish to unpublish
     */
    changeStatusToUnpublish(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToUnpublish';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }
    /**
     * 
     * this will move the article to trash
     */
    changeStatusToTrash(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToTrash';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

    /**
     * 
     * this will delete the article permanently
     */
    deleteArticle(id:number){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/deleteArticle';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

    /**
     * 
     * this will delete the article permanently
     */
    getAllTrashArticles(){
      let url = 'http://'+this.hosturl.hostName+'/ycmsweb/getAllTrashedArticles';
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.get(url);
    }

    /**
     * this will change the status of article from unfeature to feature.
     * 
     * @param id is the primary key of article on the basis of which we will change the 
     *        status of article from unfeature to feature.
     */
    changeStatusToFeatureArticle(id:number){
      let url='http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToFeature';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }

    /**
     * this will change the status of article from feature to unfeature.
     * 
     * @param id is the primary key of article on the basis of which we will change the 
     *        status of article from feature to unfeature.
     */
    changeStatusToUnfeatureArticle(id:number){
      let url='http://'+this.hosturl.hostName+'/ycmsweb/changeStatusToUnfeature';
      let data={ "id":id};
      let headers = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpclient.post(url, data, {headers: headers, withCredentials : true});
    }
    
	editArticle(fileName:String){
		let url='http://'+this.hosturl.hostName+'/ycmsweb/editArticle';
		let data = {"fileName":fileName};
		return this.httpclient.post(url , data);
	}
	
	openPage(title:string){
		let url='http://'+this.hosturl.hostName+'/ycmsweb/openpage/'+title;
		return this.httpclient.get(url);
	}
	
}
