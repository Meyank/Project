import { TestBed, inject } from '@angular/core/testing';

import { ListArticleService } from './list-article.service';

describe('ListArticleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListArticleService]
    });
  });

  it('should be created', inject([ListArticleService], (service: ListArticleService) => {
    expect(service).toBeTruthy();
  }));
});
