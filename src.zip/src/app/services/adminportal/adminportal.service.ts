import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http,Response,Headers,RequestOptions } from '@angular/http';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { HostURL } from '../../hostUrl/hostUrl';

@Injectable()
export class AdminportalService {

  constructor(private http:HttpClient,private hosturl:HostURL) { }

  getAllCustomers(){
    let url ="http://"+this.hosturl.hostName+"/ycmsweb/customers/listAll";
    return this.http.get(url, {withCredentials:true});
  }

}
