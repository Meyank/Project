import { TestBed, inject } from '@angular/core/testing';

import { AdminportalService } from './adminportal.service';

describe('AdminportalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminportalService]
    });
  });

  it('should be created', inject([AdminportalService], (service: AdminportalService) => {
    expect(service).toBeTruthy();
  }));
});
