import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { HostURL } from '../../hostUrl/hostUrl'

@Injectable()
export class HomeService {

  constructor(private httpClient: HttpClient, private hosturl: HostURL) { }

  getUrl(page) {
    console.log(page);
    let url = "http://" + this.hosturl.hostName + "/ycmsweb/customers/" + page;

    var params = { 'pageName': page }

    return this.httpClient.get(url, { observe: 'response' });
  }


}
