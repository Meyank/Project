import { TestBed, inject } from '@angular/core/testing';

import { WhatsNewService } from './whats-new.service';

describe('WhatsNewService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WhatsNewService]
    });
  });

  it('should be created', inject([WhatsNewService], (service: WhatsNewService) => {
    expect(service).toBeTruthy();
  }));
});
