import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import { Video } from '../../classes/video';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HostURL } from '../../hostUrl/hostUrl';

@Injectable()
export class PortfolioService {

  constructor(private http: HttpClient,private hosturl:HostURL) { }

  uploadInformation(file: File,title:string,name:string,secondaryname:string,facebook:string,instagram:string,github:string): Observable<Object> {
    let url = 'http://'+this.hosturl.hostName+'/ycmsweb/customers/portfolio';
    let formdata: FormData = new FormData();
    formdata.append('file', file);
	formdata.append('title',title);
	formdata.append('name',name);
	formdata.append('secondaryname',secondaryname);
	formdata.append('facebook',facebook);
	formdata.append('instagram',instagram);
	formdata.append('github',github);
    return this.http.post(url, formdata, { observe: 'response' });

  }
}
