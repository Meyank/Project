import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DataService {

  constructor() { }
   
  private messageSource=new BehaviorSubject<boolean>(false);
  currentLoginValue=this.messageSource.asObservable();
   
  changeLoginValue(loginValue:boolean){
     this.messageSource.next(loginValue);
   }
}
