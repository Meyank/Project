import { Injectable } from '@angular/core';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { HostURL }  from '../../hostUrl/hostUrl'

@Injectable()
export class EditorService {

  constructor(private httpclient:HttpClient,private hosturl:HostURL) {  }


  save(title:String,alias:String,htmlContent:String,featured:String,status:String,category:String,access:String,language:String,tags:String){
    console.log(alias);
    var article={"fileName":title, "alias":alias, "htmlContent":htmlContent,
                  "featureStatus":featured,"publishStatus":status,"category":category,"access":access,"language":language,"tag":tags}
  let url = 'http://'+this.hosturl.hostName+'/ycmsweb/articles';

  return this.httpclient.post(url, article, {observe: 'response'});
  }

checkTitle(title:String){
  let url='http://'+this.hosturl.hostName+'/ycmsweb/articles/getarticle/'+title;
return this.httpclient.get(url)
}


getCategories(){
	console.log('method');
	let url='http://'+this.hosturl.hostName+'/ycmsweb/categories/0';
	return this.httpclient.get(url);
}

}
