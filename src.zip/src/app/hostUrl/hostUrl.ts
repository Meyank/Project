/**
 * 
 * @author chetan.magre
 * 
 * this is host URL class which Defines that at what host the allpication will send request.
 */
export class HostURL{
    hostName:String="yi1007117dt:8080";
}