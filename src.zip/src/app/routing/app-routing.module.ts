import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from '../components/login/login.component';
import { RegistrationComponent } from '../components/registration/registration.component';
import { AdminportalComponent } from '../components/adminportal/adminportal.component';
import { CustomerdashboardComponent } from '../components/customerdashboard/customerdashboard.component';
import { VideoComponent } from '../components/video/video.component';
import { YcmsTutorialComponent } from '../components/ycms-tutorial/ycms-tutorial.component';
import { ListcategoriesComponent } from '../components/listcategories/listcategories.component';
import { EditorComponent } from '../components/editor/editor.component';
import { ListArticleComponent } from '../components/list-article/list-article.component';
import { CategoryComponent } from '../components/category/category.component';

const routes: Routes = [
  { path: '', redirectTo: '/registration', pathMatch: 'full' },
  { path: 'signin', component: LoginComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'customerDashboard/adminPortal', component: AdminportalComponent },
  { path: 'customerDashboard', component: CustomerdashboardComponent },
  { path: 'customerDashboard/ycmsVideoTutorials', component: VideoComponent },
  { path: 'customerDashboard/tutorial', component: YcmsTutorialComponent },
  { path: 'listArticles', component: ListArticleComponent },
  { path: 'listCategories', component: ListcategoriesComponent },
  { path: 'newArticle', component: EditorComponent },
  { path: 'newCategory', component: CategoryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
