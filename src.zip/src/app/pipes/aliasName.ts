import { Pipe, PipeTransform } from '@angular/core';

/**
 * this is the custom pipe for replacing the blank spaces in a string 
 * to '_' underscore symbol
 * this is done by implementing interface PipeTrasform 
 * Author : minerva.shrivastava
 * @Pipe({name : "aliasNamePipe"}) - the name of pipe
 */
@Pipe({name : "aliasNamePipe"})
export class AliasNamePipe implements PipeTransform{

    /**
     * this method transforms the category title provided 
     * it replaces the blank spaces by uderscore symbol
     * @param title - is category title 
     * returns the transformed title
     */
    transform(title:string):string{
        /**
         * the replace method replaces only first occurance of space,
         * therefore '/ /g' having 'g' is for global replace (all the blanck spaces)
         * 
         * title ? title.replace(/ /g,'_') : title 
         * if title is undefined an error occurs - cannot read replace() of undefined
         * therefore check before hand - if title exists, replace method is used
         *                             - if title is undefined, replace method is not used    
         * 
         */
         return title ? title.replace(/ /g,'_') : title ;
    }
}